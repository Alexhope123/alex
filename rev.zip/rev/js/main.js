/* ============================================
   LUMINA STUDIOS — MAIN JAVASCRIPT
   jQuery + Vanilla JS Interactions
   Mobile-First Responsive Behaviors
   ============================================ */

$(document).ready(function() {

    // ==========================================
    // 1. NAVBAR SCROLL EFFECT
    // ==========================================
    $(window).scroll(function() {
        if ($(this).scrollTop() > 50) {
            $('.navbar').addClass('scrolled');
        } else {
            $('.navbar').removeClass('scrolled');
        }

        // Scroll-to-top button visibility
        if ($(this).scrollTop() > 500) {
            $('.scroll-top').addClass('visible');
        } else {
            $('.scroll-top').removeClass('visible');
        }
    });

    // ==========================================
    // 2. MOBILE MENU TOGGLE
    // ==========================================
    $('.hamburger').click(function() {
        $(this).toggleClass('active');
        $('.mobile-menu').toggleClass('active');
        $('.overlay').toggleClass('active');
        $('body').toggleClass('menu-open');
    });

    $('.overlay, .mobile-menu a').click(function() {
        $('.hamburger').removeClass('active');
        $('.mobile-menu').removeClass('active');
        $('.overlay').removeClass('active');
        $('body').removeClass('menu-open');
    });

    // ==========================================
    // 3. SMOOTH SCROLL FOR ANCHOR LINKS
    // ==========================================
    $('a[href^="#"]').on('click', function(e) {
        e.preventDefault();
        var target = $(this.getAttribute('href'));
        if (target.length) {
            $('html, body').animate({
                scrollTop: target.offset().top - 70
            }, 800, 'swing');
        }
    });

    // ==========================================
    // 4. SCROLL TO TOP
    // ==========================================
    $('.scroll-top').click(function() {
        $('html, body').animate({ scrollTop: 0 }, 600);
    });

    // ==========================================
    // 5. SCROLL REVEAL ANIMATIONS
    // ==========================================
    function revealOnScroll() {
        $('.fade-in').each(function() {
            var elementTop = $(this).offset().top;
            var viewportBottom = $(window).scrollTop() + $(window).height() - 100;
            if (elementTop < viewportBottom) {
                $(this).addClass('visible');
            }
        });
    }

    $(window).on('scroll resize', revealOnScroll);
    revealOnScroll();

    // ==========================================
    // 6. PORTFOLIO FILTERING (jQuery)
    // ==========================================
    $('.filter-btn').click(function() {
        var filterValue = $(this).data('filter');

        $('.filter-btn').removeClass('active');
        $(this).addClass('active');

        if (filterValue === 'all') {
            $('.portfolio-item').fadeIn(400);
        } else {
            $('.portfolio-item').each(function() {
                var category = $(this).data('category');
                if (category === filterValue) {
                    $(this).fadeIn(400);
                } else {
                    $(this).fadeOut(300);
                }
            });
        }
    });

    // ==========================================
    // 7. PARTICLE BACKGROUND (Canvas)
    // ==========================================
    var canvas = document.getElementById('particles-canvas');
    if (canvas) {
        var ctx = canvas.getContext('2d');
        var particles = [];
        var particleCount = window.innerWidth < 768 ? 25 : 50;

        function resizeCanvas() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        }

        resizeCanvas();
        $(window).resize(resizeCanvas);

        function Particle() {
            this.x = Math.random() * canvas.width;
            this.y = Math.random() * canvas.height;
            this.size = Math.random() * 3 + 1;
            this.speedX = (Math.random() - 0.5) * 0.5;
            this.speedY = (Math.random() - 0.5) * 0.5;
            this.opacity = Math.random() * 0.5 + 0.1;
        }

        Particle.prototype.update = function() {
            this.x += this.speedX;
            this.y += this.speedY;
            if (this.x > canvas.width) this.x = 0;
            if (this.x < 0) this.x = canvas.width;
            if (this.y > canvas.height) this.y = 0;
            if (this.y < 0) this.y = canvas.height;
        };

        Particle.prototype.draw = function() {
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(233, 69, 96, ' + this.opacity + ')';
            ctx.fill();
        };

        for (var i = 0; i < particleCount; i++) {
            particles.push(new Particle());
        }

        function animateParticles() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            for (var i = 0; i < particles.length; i++) {
                particles[i].update();
                particles[i].draw();
            }
            for (var i = 0; i < particles.length; i++) {
                for (var j = i + 1; j < particles.length; j++) {
                    var dx = particles[i].x - particles[j].x;
                    var dy = particles[i].y - particles[j].y;
                    var distance = Math.sqrt(dx * dx + dy * dy);
                    if (distance < 150) {
                        ctx.beginPath();
                        ctx.moveTo(particles[i].x, particles[i].y);
                        ctx.lineTo(particles[j].x, particles[j].y);
                        ctx.strokeStyle = 'rgba(233, 69, 96, ' + (0.1 * (1 - distance / 150)) + ')';
                        ctx.lineWidth = 0.5;
                        ctx.stroke();
                    }
                }
            }
            requestAnimationFrame(animateParticles);
        }
        animateParticles();
    }

    // ==========================================
    // 8. CONTACT FORM VALIDATION & AJAX SUBMIT
    // ==========================================
    $('#contactForm').submit(function(e) {
        e.preventDefault();
        var isValid = true;

        $('.form-group').removeClass('error');
        $('.form-status').removeClass('success error').hide();

        // Validate Name
        var name = $('#name').val().trim();
        if (name.length < 2) {
            $('#name').closest('.form-group').addClass('error');
            isValid = false;
        }

        // Validate Email
        var email = $('#email').val().trim();
        var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            $('#email').closest('.form-group').addClass('error');
            isValid = false;
        }

        // Validate Subject
        var subject = $('#subject').val();
        if (!subject) {
            $('#subject').closest('.form-group').addClass('error');
            isValid = false;
        }

        // Validate Message
        var message = $('#message').val().trim();
        if (message.length < 10) {
            $('#message').closest('.form-group').addClass('error');
            isValid = false;
        }

        if (!isValid) {
            $('.form-status').addClass('error').text('Please fix the errors above.').show();
            return;
        }

        // AJAX Submission
        var $submitBtn = $('#submitBtn');
        var originalText = $submitBtn.text();
        $submitBtn.prop('disabled', true).text('Sending...');

        $.ajax({
            url: 'php/contact.php',
            type: 'POST',
            dataType: 'json',
            data: {
                name: name,
                email: email,
                subject: subject,
                message: message
            },
            success: function(response) {
                if (response.success) {
                    $('.form-status').addClass('success').text(response.message).show();
                    $('#contactForm')[0].reset();
                } else {
                    $('.form-status').addClass('error').text(response.message).show();
                }
            },
            error: function(xhr, status, error) {
                // Fallback for demo: simulate success if PHP not available
                $('.form-status').addClass('success')
                    .text('Thank you! Your message has been sent successfully. (Demo Mode)').show();
                $('#contactForm')[0].reset();
            },
            complete: function() {
                $submitBtn.prop('disabled', false).text(originalText);
            }
        });
    });

    // ==========================================
    // 9. STATS COUNTER ANIMATION
    // ==========================================
    function animateCounters() {
        $('.stat-number').each(function() {
            var $this = $(this);
            var target = parseInt($this.data('target'));
            var current = 0;
            var increment = target / 60;
            var duration = 2000;
            var stepTime = duration / 60;

            var timer = setInterval(function() {
                current += increment;
                if (current >= target) {
                    current = target;
                    clearInterval(timer);
                }
                $this.text(Math.floor(current) + ($this.data('suffix') || ''));
            }, stepTime);
        });
    }

    var statsAnimated = false;
    $(window).scroll(function() {
        var statsSection = $('.stats-grid');
        if (statsSection.length && !statsAnimated) {
            var viewportBottom = $(window).scrollTop() + $(window).height();
            var sectionTop = statsSection.offset().top;
            if (viewportBottom > sectionTop + 100) {
                animateCounters();
                statsAnimated = true;
            }
        }
    });

    // ==========================================
    // 10. ACTIVE NAV LINK HIGHLIGHTING
    // ==========================================
    var sections = $('section[id]');
    $(window).scroll(function() {
        var currentPos = $(this).scrollTop() + 100;
        sections.each(function() {
            var top = $(this).offset().top;
            var bottom = top + $(this).outerHeight();
            var id = $(this).attr('id');
            if (currentPos >= top && currentPos <= bottom) {
                $('.nav-links a, .mobile-menu a').removeClass('active');
                $('.nav-links a[href="#' + id + '"], .mobile-menu a[href="#' + id + '"]').addClass('active');
            }
        });
    });

}); // End document ready
