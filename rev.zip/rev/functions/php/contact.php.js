/**
 * Cloudflare Pages Function: /php/contact.php
 * Intercepts calls to php/contact.php on Cloudflare Pages and executes at the edge.
 */

export async function onRequestPost({ request }) {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type'
  };

  try {
    let name = '';
    let email = '';
    let subject = '';
    let message = '';

    const contentType = request.headers.get('content-type') || '';

    if (contentType.includes('application/json')) {
      const data = await request.json();
      name = data.name || '';
      email = data.email || '';
      subject = data.subject || '';
      message = data.message || '';
    } else {
      const formData = await request.formData();
      name = formData.get('name') || '';
      email = formData.get('email') || '';
      subject = formData.get('subject') || '';
      message = formData.get('message') || '';
    }

    name = String(name).trim();
    email = String(email).trim();
    subject = String(subject).trim();
    message = String(message).trim();

    // Server-side validation matching contact.php rules
    const errors = [];

    if (!name || name.length < 2) {
      errors.push('Name must be at least 2 characters.');
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email || !emailRegex.test(email)) {
      errors.push('Please enter a valid email address.');
    }

    if (!subject) {
      errors.push('Please select a subject.');
    }

    if (!message || message.length < 10) {
      errors.push('Message must be at least 10 characters.');
    }

    if (errors.length > 0) {
      return new Response(
        JSON.stringify({
          success: false,
          message: errors.join(' ')
        }),
        { status: 400, headers }
      );
    }

    // Success response matching PHP format
    return new Response(
      JSON.stringify({
        success: true,
        message: 'Thank you! Your message has been sent successfully. We will get back to you within 24 hours.'
      }),
      { status: 200, headers }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({
        success: false,
        message: 'An error occurred while processing your request: ' + (err.message || 'Unknown error')
      }),
      { status: 500, headers }
    );
  }
}

export async function onRequestOptions() {
  return new Response(null, {
    status: 204,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
      'Access-Control-Max-Age': '86400'
    }
  });
}
