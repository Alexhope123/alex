<?php
/* ============================================
   LUMINA STUDIOS — CONTACT FORM PROCESSOR
   Server-side validation & AJAX response
   ============================================ */

header('Content-Type: application/json');

// Response array
$response = array('success' => false, 'message' => '');

// Check if request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $response['message'] = 'Invalid request method.';
    echo json_encode($response);
    exit;
}

// Retrieve and sanitize inputs
$name = isset($_POST['name']) ? htmlspecialchars(trim($_POST['name']), ENT_QUOTES, 'UTF-8') : '';
$email = isset($_POST['email']) ? filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL) : '';
$subject = isset($_POST['subject']) ? htmlspecialchars(trim($_POST['subject']), ENT_QUOTES, 'UTF-8') : '';
$message = isset($_POST['message']) ? htmlspecialchars(trim($_POST['message']), ENT_QUOTES, 'UTF-8') : '';

// Server-side validation
$errors = array();

if (empty($name) || strlen($name) < 2) {
    $errors[] = 'Name must be at least 2 characters.';
}

if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'Please enter a valid email address.';
}

if (empty($subject)) {
    $errors[] = 'Please select a subject.';
}

if (empty($message) || strlen($message) < 10) {
    $errors[] = 'Message must be at least 10 characters.';
}

// Return errors if any
if (!empty($errors)) {
    $response['message'] = implode(' ', $errors);
    echo json_encode($response);
    exit;
}

// Compose email (in production, configure SMTP)
$to = 'hello@luminastudios.com';
$emailSubject = 'New Contact Form Submission: ' . $subject;
$emailBody = "Name: $name
";
$emailBody .= "Email: $email
";
$emailBody .= "Subject: $subject
";
$emailBody .= "Message:
$message
";
$emailBody .= "Submitted at: " . date('Y-m-d H:i:s') . "
";
$emailBody .= "IP Address: " . $_SERVER['REMOTE_ADDR'] . "
";

$headers = "From: $email
";
$headers .= "Reply-To: $email
";
$headers .= "X-Mailer: PHP/" . phpversion();

// Attempt to send email (mail() may be disabled on some servers)
$mailSent = @mail($to, $emailSubject, $emailBody, $headers);

// Log to file as backup
$logEntry = date('Y-m-d H:i:s') . " | Name: $name | Email: $email | Subject: $subject
";
$logFile = __DIR__ . '/submissions.log';
@file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);

// Return success response
$response['success'] = true;
$response['message'] = 'Thank you! Your message has been sent successfully. We will get back to you within 24 hours.';

echo json_encode($response);
exit;
?>